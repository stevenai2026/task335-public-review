# Public release notes V1.2

Supersedes V1.0/V1.1 public documentation. New standalone PDF includes all four sample descriptions and observed local fault-test results. No production export or external publication.

The user-supplied second review is acknowledged, not independently authenticated. Historical evidence remains separately labeled. Sample MIT license applies only within workflow_samples/.
