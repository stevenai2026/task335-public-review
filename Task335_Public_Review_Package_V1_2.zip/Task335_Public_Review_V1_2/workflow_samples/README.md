# Public workflow samples V1.2 / 对外样本

These are synthetic review examples, NOT exported production workflows. The first three JSON files use n8n Manual Trigger and Code nodes. Sample 04 is a standalone Python/SQLite fault experiment, NOT n8n JSON. No n8n import/execution or iPad validation was performed.

| Sample | Demonstration | Expected outcome |
|---|---|---|
| 01 | A reserves a call slot, mock B returns 5, A independently recomputes 2+3 | ACCEPTED; wrong result 6 rejected; no durable readback claim |
| 02 | Exact-content SHA-256 in source/item/version dedup key | 2 new, 1 duplicate, 1 source failure; PARTIAL |
| 03 | Call count + worst-case money/token cost + expiry/revocation/STOP/version/uncertainty | 8 stops/holds and 1 ready |
| 04 | SQLite atomic claim and reservation, subprocess crash and loopback mock endpoint | See actual test_receipt.json |

01 only verifies deterministic arithmetic, not general research. 02 only deduplicates within one run; page noise may change hashes. 03 uses synthetic integer micro-USD/token bounds; no real pricing or persistent reservation. 04 uses integer synthetic cost units and one local SQLite host; it does not certify the real n8n/Sheets path.

## Run / 使用

Import 01–03 JSON via n8n Import from File in an isolated test project. Actual import compatibility remains unverified. No credentials or external requests are included. Native n8n executions can still consume your plan allowance.

Local code replay: `node verify_samples.js`.
Persistent test: `python3 04_persistent_fault_demo/verify.py` (Python standard library; local loopback socket required). Neither requires paid models. Test time and compute are not literally free.

先读说明即可；不需要 Steven 在 iPad 操作。04 的数据库为每轮独立临时 SQLite 文件，崩溃子进程结束后由新连接恢复，测试结束清理。它证明进程崩溃后的持久性，不证明断电、跨主机或生产系统恢复。

Code files in workflow_samples are MIT licensed; see LICENSE. Original reports and historical artifacts are not included in that license.

Official references: https://docs.n8n.io/workflows/export-import/ ; https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.code/
