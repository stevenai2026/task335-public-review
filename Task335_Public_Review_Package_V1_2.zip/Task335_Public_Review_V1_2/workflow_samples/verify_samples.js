const fs=require('fs');const assert=require('assert');const path=require('path');
const results=[];
for(const file of ['01_AB_review_demo.json','02_scan_dedup_demo.json','03_stop_budget_demo.json']){
 const wf=JSON.parse(fs.readFileSync(path.join(__dirname,file),'utf8'));assert.strictEqual(wf.active,false);
 const names=new Set(wf.nodes.map(n=>n.name));assert.strictEqual(names.size,wf.nodes.length);
 for(const [source,c] of Object.entries(wf.connections)){assert(names.has(source));for(const branch of c.main)for(const edge of branch)assert(names.has(edge.node));}
 let items=[{json:{}}];let current=wf.nodes[0];let visited=0;
 while(current){assert(!current.credentials);assert(['n8n-nodes-base.manualTrigger','n8n-nodes-base.code'].includes(current.type));
 if(current.type==='n8n-nodes-base.code'){items=new Function('$input','require',current.parameters.jsCode)({all:()=>items},require);assert(Array.isArray(items));for(const i of items)assert(i.json && typeof i.json==='object');}
 visited++;const next=wf.connections[current.name]?.main[0]?.[0]?.node;current=next?wf.nodes.find(n=>n.name===next):null;assert(visited<=wf.nodes.length);}
 assert.strictEqual(visited,wf.nodes.length);
 if(file.startsWith('01')){assert.strictEqual(items[0].json.status,'ACCEPTED');assert.strictEqual(items[0].json.answer,5);assert.strictEqual(items[0].json.actual_paid_calls,0);}
 if(file.startsWith('02')){assert.deepStrictEqual([items[0].json.status,items[0].json.new_count,items[0].json.duplicate_count,items[0].json.failed_count],['PARTIAL',2,1,1]);}
 if(file.startsWith('03'))assert.deepStrictEqual(items[0].json.cases.map(x=>x.decision),['STOP_BUDGET','STOP_BUDGET','STOP_BUDGET','STOP_EXPIRED','STOP_REVOKED','STOP_REQUESTED','STOP_VERSION','HOLD_RECONCILE','READY_SIMULATION']);
 if(file.startsWith('01')){const check=wf.nodes.find(n=>n.name==='A Verify Result');const wrong=new Function('$input',check.parameters.jsCode)({all:()=>[{json:{status:'RESERVED',operation:'sum',operands:[2,3],answer:6}}]});assert.strictEqual(wrong[0].json.status,'HOLD');}
 results.push({file,node_count:wf.nodes.length,status:'LOCAL_CODE_REPLAY_PASS',output:items});
}
console.log(JSON.stringify({scope:'Synthetic public samples only; Node.js replay, NOT n8n runtime',n8n_import_test:'NOT_RUN',ipad_test:'NOT_RUN',results},null,2));
