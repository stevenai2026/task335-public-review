"""Public synthetic SQLite fault demonstration. Python stdlib; loopback HTTP only.
Not an n8n workflow, production engine, provider billing test or distributed DB test.
Run: python3 verify.py. Temporary databases contain synthetic data and are removed.
"""
import sqlite3, tempfile, pathlib, multiprocessing as mp, threading, json, os
import urllib.request, hashlib, platform
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

def db(path):
    c=sqlite3.connect(path,timeout=15,isolation_level=None)
    c.execute('PRAGMA busy_timeout=15000')
    return c

def init(path, ids, budget=3):
    with db(path) as c:
        c.executescript('''CREATE TABLE tasks(id TEXT PRIMARY KEY,status TEXT NOT NULL,attempt INTEGER NOT NULL DEFAULT 0,op TEXT UNIQUE);
        CREATE TABLE budget(id INTEGER PRIMARY KEY CHECK(id=1),available INTEGER NOT NULL CHECK(available>=0),reserved INTEGER NOT NULL CHECK(reserved>=0));
        CREATE TABLE reservations(op TEXT PRIMARY KEY,task TEXT UNIQUE NOT NULL,cost INTEGER NOT NULL);
        CREATE TABLE results(op TEXT PRIMARY KEY,body TEXT,sha256 TEXT);''')
        c.execute('INSERT INTO budget VALUES(1,?,0)',(budget,))
        c.executemany("INSERT INTO tasks(id,status) VALUES(?,'PENDING')",[(i,) for i in ids])

def reserve(path, task, cost=3):
    # Claim and worst-case cost reservation share one short database transaction.
    c=db(path)
    try:
        c.execute('BEGIN IMMEDIATE')
        row=c.execute('SELECT status,attempt FROM tasks WHERE id=?',(task,)).fetchone()
        if not row or row[0]!='PENDING': c.rollback();return None
        attempt=row[1]+1
        op=hashlib.sha256(f'{task}|input-v1|{attempt}|model-step'.encode()).hexdigest()
        n=c.execute('UPDATE budget SET available=available-?,reserved=reserved+? WHERE id=1 AND available>=?',(cost,cost,cost)).rowcount
        if n!=1:c.rollback();return None
        n=c.execute("UPDATE tasks SET status='CALLING',attempt=?,op=? WHERE id=? AND status='PENDING' AND attempt=?",(attempt,op,task,row[1])).rowcount
        if n!=1:c.rollback();return None
        c.execute('INSERT INTO reservations VALUES(?,?,?)',(op,task,cost))
        c.commit();return op
    except: c.rollback();raise
    finally:c.close()

def race(path,task,barrier,queue):
    barrier.wait(timeout=15)
    queue.put(bool(reserve(path,task)))

def concurrent(path,ids):
    ctx=mp.get_context('spawn');b=ctx.Barrier(2);q=ctx.Queue()
    ps=[ctx.Process(target=race,args=(str(path),i,b,q)) for i in ids]
    for p in ps:p.start()
    for p in ps:p.join(25);assert not p.is_alive() and p.exitcode==0
    return sorted([q.get(timeout=5),q.get(timeout=5)])

def call_then_crash(path,url,task):
    op=reserve(path,task)
    if not op:os._exit(24)
    payload=json.dumps({'operation_id':op,'input':'synthetic'}).encode()
    req=urllib.request.Request(url,data=payload,headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=10) as r:
        response=json.loads(r.read())
    if not response.get('mock_request_id'):os._exit(25)
    # Endpoint has committed success and client has received it; no result persisted.
    os._exit(23)

def recover_after_confirmed_process_death(path):
    # Only safe here because the test has joined the dead caller.
    # Production must prove lease expiry/owner death and fence stale writers.
    with db(path) as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute("UPDATE tasks SET status='UNCERTAIN' WHERE status='CALLING' AND NOT EXISTS (SELECT 1 FROM results r WHERE r.op=tasks.op)")
        c.commit()

def run(rounds=20):
    rows=[]
    with tempfile.TemporaryDirectory(prefix='public-synthetic-') as tmp:
        base=pathlib.Path(tmp);provider=base/'mock-provider.sqlite'
        with db(provider) as c:c.execute('CREATE TABLE requests(id INTEGER PRIMARY KEY,op TEXT NOT NULL)')
        class Endpoint(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                with db(provider) as c:
                    cur=c.execute('INSERT INTO requests(op) VALUES(?)',(data['operation_id'],));rid=cur.lastrowid
                body=json.dumps({'mock_request_id':f'mock-{rid}','answer':5,'usage':{'input_tokens':4,'output_tokens':1}}).encode()
                self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        server=ThreadingHTTPServer(('127.0.0.1',0),Endpoint)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        url=f'http://127.0.0.1:{server.server_port}/mock-model'
        try:
            for i in range(rounds):
                p=base/f'claim-{i}.sqlite';init(p,['same'],budget=6)
                assert concurrent(p,['same','same'])==[False,True]
                with db(p) as c:
                    assert c.execute('SELECT count(*) FROM reservations').fetchone()[0]==1
                    assert c.execute('SELECT available,reserved FROM budget').fetchone()==(3,3)
                rows.append({'round':i+1,'case':'concurrent_same_task_claim','status':'PASS'})
                p=base/f'budget-{i}.sqlite';init(p,['first','second'],budget=3)
                assert concurrent(p,['first','second'])==[False,True]
                with db(p) as c:
                    assert c.execute('SELECT available,reserved FROM budget').fetchone()==(0,3)
                    assert c.execute("SELECT count(*) FROM tasks WHERE status='PENDING'").fetchone()[0]==1
                rows.append({'round':i+1,'case':'concurrent_last_budget','status':'PASS'})
                task=f'crash-task-{i}';p=base/f'crash-{i}.sqlite';init(p,[task])
                ctx=mp.get_context('spawn');worker=ctx.Process(target=call_then_crash,args=(str(p),url,task));worker.start();worker.join(20)
                assert not worker.is_alive() and worker.exitcode==23
                recover_after_confirmed_process_death(p)
                # New connections emulate reopened persistence; repeated recovery is idempotent.
                recover_after_confirmed_process_death(p)
                assert reserve(p,task) is None
                with db(p) as c:
                    status,op=c.execute('SELECT status,op FROM tasks').fetchone()
                    assert status=='UNCERTAIN'
                    assert c.execute('SELECT available,reserved FROM budget').fetchone()==(0,3)
                    assert c.execute('SELECT count(*) FROM results').fetchone()[0]==0
                with db(provider) as c:assert c.execute('SELECT count(*) FROM requests WHERE op=?',(op,)).fetchone()[0]==1
                # Unique task per round; exactly one persisted endpoint request per operation.
                rows.append({'round':i+1,'case':'post_success_pre_write_crash','status':'PASS','process_exit':23,'reserved_units':3,'resend_attempt_blocked':True})
            with db(provider) as c:requests=c.execute('SELECT count(*) FROM requests').fetchone()[0]
            assert requests==rounds
        finally:server.shutdown();server.server_close();thread.join(5)
    return {'scope':'Linux SQLite synthetic subprocess and loopback HTTP experiment','python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'rounds_per_case':rounds,'cases_passed':len(rows),'mock_http_requests':requests,'paid_model_calls':0,'n8n_execution':'NOT_RUN','ipad_test':'NOT_RUN','limits':['Local single-host SQLite only','No distributed network partition or host power-loss test','Crash recovery requires confirmed dead owner; no production leases implemented','Integer synthetic cost units, not provider billing','No original Task335 workflow executed'],'results':rows}

if __name__=='__main__':print(json.dumps(run(),indent=2,ensure_ascii=False))
